import React from 'react';
import shoppingCart from './shopping-cart.png'

export default function CartWidget() {
  return (
    <div>
        <img src={shoppingCart} alt="" />
    </div>
  );
}
