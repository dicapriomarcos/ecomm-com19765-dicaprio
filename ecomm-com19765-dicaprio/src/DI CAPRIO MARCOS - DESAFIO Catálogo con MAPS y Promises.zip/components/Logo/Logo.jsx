import React from 'react';
import './Logo.css'

export default function Logo() {
  return (
    <div id="logo">
        {/*<img src={logo} alt="" />*/}
        AmoMiMóvil Shop
    </div>
  );
}
